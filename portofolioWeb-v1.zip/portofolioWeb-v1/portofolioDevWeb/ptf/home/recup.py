from django.db import recup

# Create your models here.

class Infos(models.Model):
  name = recup.CharField(max_length=255)
  details = recup.CharField(max_length=955)