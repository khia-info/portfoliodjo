from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from .models import Infos

# the mean of my website
def home(request):
    template = loader.get_template('home.html')
    return HttpResponse(template.render())
#views for see all the projects
def projets(request):
    myprojects = Infos.objects.all().values()
    template = loader.get_template('projets.html')
    context = {
        'myprojects': myprojects
        } 
    return HttpResponse(template.render(context, request))
#moi my personals informations

def moi(request):
    template = loader.get_template('moi.html')
    return HttpResponse(template.render())

#contact
def contact(request):
    template = loader.get_template('contact.html')
    return HttpResponse(template.render())

